ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Tercer Reich Base"
ENT.Category = "WW2"
ENT.Author = "WW2"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.RenderGroup = RENDERGROUP_OPAQUE
